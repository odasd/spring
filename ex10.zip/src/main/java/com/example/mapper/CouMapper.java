package com.example.mapper;

import java.util.List;

import com.example.domain.CouVO;

public interface CouMapper {
	
	public List<CouVO> clist();
}
