package com.example.mapper;

import java.util.List;

import com.example.domain.Criteria;
import com.example.domain.ProVO;
import com.example.domain.StuVO;

public interface ProMapper {
	
	public List<ProVO> plist();
	
}
