package com.example.mapper;

import java.util.ArrayList;

import com.example.domain.ProfessorsVO;

public interface ProfessorsMapper {
	
	public ArrayList<ProfessorsVO> list();
}
